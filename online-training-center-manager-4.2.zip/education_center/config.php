<?php
	$dbServer = 'localhost';
	$dbUsername = 'root';
	$dbPassword = '';
	$dbDatabase = 'education_center';

	$adminConfig = array(
		'adminUsername' => "admin",
		'adminPassword' => "12b6cdb18079f4940890c1d3ff44a221",
		'notifyAdminNewMembers' => "",
		'defaultSignUp' => "1",
		'anonymousGroup' => "anonymous",
		'anonymousMember' => "guest",
		'groupsPerPage' => "10",
		'membersPerPage' => "10",
		'recordsPerPage' => "10",
		'custom1' => "Full Name",
		'custom2' => "Address",
		'custom3' => "City",
		'custom4' => "State",
		'MySQLDateFormat' => "%d.%m.%Y",
		'PHPDateFormat' => "j.n.Y",
		'PHPDateTimeFormat' => "d.m.Y, h:i a",
		'senderName' => "Membership management",
		'senderEmail' => "support@bigprof.com",
		'approvalSubject' => "Your membership is now approved",
		'approvalMessage' => "Dear member,\n\nYour membership is now approved by the admin. You can log in to your account here:\nhttp://localhost/education_center\n\nRegards,\nAdmin",
		'hide_twitter_feed' => ""
	);